# API REST trabajo en clases

-   Proyecto que hicimos en clases en vivo en [twitch.tv/bluuweb](https://twitch.tv/bluuweb)
